@javax.xml.bind.annotation.XmlSchema(namespace = "http://impl.services.travelapp.wspublic.alpi")
package com.certimeter.learnsoap.soap.wsdl.travelapp.services;
