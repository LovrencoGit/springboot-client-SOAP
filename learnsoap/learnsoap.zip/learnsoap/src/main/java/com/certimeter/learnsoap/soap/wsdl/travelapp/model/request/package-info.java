@javax.xml.bind.annotation.XmlSchema(namespace = "http://request.model.travelapp.wspublic.alpi")
package com.certimeter.learnsoap.soap.wsdl.travelapp.model.request;
